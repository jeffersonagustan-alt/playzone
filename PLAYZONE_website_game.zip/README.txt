PLAYZONE — Website Game Mini
=============================

Isi:
- index.html: website lengkap, termasuk tiga game yang berjalan di browser:
  1. Turbo Race 2D
  2. Kuis Pintar
  3. Pasangan Kartu

Coba secara lokal:
1. Ekstrak ZIP.
2. Buka index.html dengan browser modern (Chrome, Edge, Firefox, Safari).

Terbitkan agar punya link publik:
Opsi GitHub Pages:
1. Masuk ke https://github.com dan buat repository baru, misalnya `playzone`.
2. Unggah `index.html` ke root repository.
3. Buka Settings → Pages.
4. Pada Build and deployment, pilih Deploy from a branch, branch `main`, folder `/(root)`, lalu Save.
5. Setelah deployment selesai, GitHub akan menampilkan URL publik berbentuk https://USERNAME.github.io/playzone/

Alternatif:
- Netlify: https://app.netlify.com/ → Add new site / Deploy manually, lalu unggah folder yang berisi index.html.
- URL publik dibuat oleh layanan hosting; belum ada URL publik yang diterbitkan otomatis oleh file ini.

Catatan:
- Skor dan rekor disimpan secara lokal pada browser/perangkat yang sama.
- Website ini tidak memerlukan server atau database.
